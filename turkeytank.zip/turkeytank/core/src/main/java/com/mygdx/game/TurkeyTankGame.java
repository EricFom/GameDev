package com.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class TurkeyTankGame extends ApplicationAdapter {
    SpriteBatch batch;
    ShapeRenderer sr;
    BitmapFont font;

    final int WORLD_W = 800;
    final int WORLD_H = 480;

    Texture turkeySheet;
    TextureRegion turkeyRegionLeft;
    TextureRegion turkeyRegionRight;
    TextureRegion drumstickRegion;
    TextureRegion wishboneRegion;

    float tankDrawW = 64f;
    float tankDrawH = 64f;

    float[] ground;
    Random rnd = new Random(1234);

    Tank[] tanks = new Tank[2];
    int currentPlayer = 0; // whose turn

    ArrayList<Projectile> projectiles = new ArrayList<>();
    float gravity = -400f;

    final int SHEET_COLS = 6;
    final int SHEET_ROWS = 5;

    enum GameState { TITLE_SCREEN, PLAYING, GAME_OVER }
    GameState gameState = GameState.TITLE_SCREEN;
    int winner = -1;
    Texture titleScreenTexture;

    Sound shootSound;

    @Override
    public void create() {
        batch = new SpriteBatch();
        sr = new ShapeRenderer();
        font = new BitmapFont();
        font.getData().setScale(1.2f);

        generateGround();

        tanks[0] = new Tank(100, getGroundHeight(100) + 10, true);
        tanks[1] = new Tank(500, getGroundHeight(500) + 10, false);

        tanks[0].health = 100;
        tanks[1].health = 100;

        try {
            turkeySheet = new Texture(Gdx.files.internal("turkey_sheet.png"));
            int cellW = turkeySheet.getWidth() / SHEET_COLS;
            int cellH = turkeySheet.getHeight() / SHEET_ROWS;

            turkeyRegionLeft = new TextureRegion(turkeySheet, 0 * cellW, 0 * cellH, cellW, cellH);
            turkeyRegionRight = new TextureRegion(turkeyRegionLeft);
            turkeyRegionLeft.flip(true, false);

            drumstickRegion = new TextureRegion(turkeySheet, 0 * cellW, 4 * cellH, cellW, cellH);
            wishboneRegion = new TextureRegion(turkeySheet, 1 * cellW, 4 * cellH, cellW, cellH);

            tankDrawW = Math.max(48f, cellW * 1.0f);
            tankDrawH = Math.max(48f, cellH * 1.0f);
        } catch (Exception e) {
            turkeySheet = null;
            turkeyRegionLeft = turkeyRegionRight = null;
            drumstickRegion = wishboneRegion = null;
            Gdx.app.error("TurkeyTankGame", "Failed loading turkey_sheet.png from core/assets", e);
        }

        try {
            shootSound = Gdx.audio.newSound(Gdx.files.internal("shoot.wav"));
        } catch (Exception e) {
            shootSound = null;
            Gdx.app.error("TurkeyTankGame", "Failed loading shoot sound", e);
        }
        try {
            titleScreenTexture = new Texture(Gdx.files.internal("title_screen.png"));
        } catch (Exception e) {
            titleScreenTexture = null;
            Gdx.app.error("TurkeyTankGame", "Failed loading title_screen.png", e);
        }
    }

    void generateGround() {
        ground = new float[WORLD_W + 1];
        float base = 80;
        for (int x = 0; x <= WORLD_W; x++) ground[x] = base + (float) (30 * Math.sin(x * 0.02) + 15 * Math.sin(x * 0.07));
    }

    float getGroundHeight(float x) {
        int xi = Math.max(0, Math.min(WORLD_W, Math.round(x)));
        return ground[xi];
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0.6f, 0.8f, 1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if (gameState == GameState.TITLE_SCREEN) {
            renderTitleScreen();
        } else if (gameState == GameState.PLAYING) {
            renderGame();
        } else if (gameState == GameState.GAME_OVER) {
            renderGameOver();
        }
    }

    void renderTitleScreen() {
        batch.begin();
        if (titleScreenTexture != null) {
            batch.draw(titleScreenTexture, 0, 0, WORLD_W, WORLD_H);
        } else {
            font.draw(batch, "TURKEY TANK GAME", WORLD_W / 2f - 100, WORLD_H / 2f + 50);
            font.draw(batch, "Click or Press SPACE to Start", WORLD_W / 2f - 120, WORLD_H / 2f);
        }
        batch.end();

        if (Gdx.input.justTouched() || Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            gameState = GameState.PLAYING;
        }
    }

    void renderGame() {
        float dt = Math.min(1 / 30f, Gdx.graphics.getDeltaTime());
        handleInput(dt);
        updateProjectiles(dt);

        if (tanks[0].health <= 0) {
            winner = 1;
            gameState = GameState.GAME_OVER;
            projectiles.clear();
            return;
        } else if (tanks[1].health <= 0) {
            winner = 0;
            gameState = GameState.GAME_OVER;
            projectiles.clear();
            return;
        }

        sr.setProjectionMatrix(batch.getProjectionMatrix());
        batch.setProjectionMatrix(batch.getProjectionMatrix());

        sr.begin(ShapeRenderer.ShapeType.Filled);
        for (int x = 0; x < WORLD_W; x++) sr.rect(x, 0, 1, ground[x]);
        sr.end();

        batch.begin();

        Tank t1 = tanks[0];
        if (turkeyRegionLeft != null) {
            batch.draw(turkeyRegionLeft, t1.x - tankDrawW / 2f, t1.y - tankDrawH / 2f, tankDrawW, tankDrawH);
        }

        Tank t2 = tanks[1];
        if (turkeyRegionRight != null) {
            batch.draw(turkeyRegionRight, t2.x - tankDrawW / 2f, t2.y - tankDrawH / 2f, tankDrawW, tankDrawH);
        }

        for (Projectile p: projectiles) {
            if (p.spriteRegion != null) {
                float baseW = p.spriteRegion.getRegionWidth();
                float baseH = p.spriteRegion.getRegionHeight();
                float w = baseW * p.spriteScale;
                float h = baseH * p.spriteScale;
                batch.draw(p.spriteRegion, p.pos.x - w / 2f, p.pos.y - h / 2f, w, h);
            }
        }

        String hud = "P" + (currentPlayer + 1) + " turn   |   Weapon: " + tanks[currentPlayer].selected.name() + "   |   Power: " + Math.round(tanks[currentPlayer].power);
        float hudX = 50;
        float hudY = WORLD_H - 10;
        font.draw(batch, hud, hudX, hudY);

        batch.end();

        sr.begin(ShapeRenderer.ShapeType.Filled);

        for (int i = 0; i < 2; i++) {
            Tank t = tanks[i];
            float bx = (float) (t.x + Math.cos(Math.toRadians(t.angle)) * t.barrelLength);
            float by = (float) (t.y + Math.sin(Math.toRadians(t.angle)) * t.barrelLength);
            sr.setColor(0, 0, 0, 1);
            sr.rectLine(t.x, t.y, bx, by, 3);

            float hbW = 64, hbH = 8, hx = t.x - hbW / 2f, hy = t.y + tankDrawH / 2f + 8;
            sr.setColor(0, 0, 0, 1);
            sr.rect(hx - 1, hy - 1, hbW + 2, hbH + 2);
            float pct = Math.max(0, t.health) / 100f;
            sr.setColor(1 - pct, pct, 0, 1);
            sr.rect(hx, hy, hbW * pct, hbH);
            sr.setColor(1, 1, 1, 1);
        }

        for (Projectile p: projectiles) {
            if (p.type == ProjectileType.CRANBERRY) {
                sr.setColor(1, 0, 0, 1);
                sr.circle(p.pos.x, p.pos.y, Math.max(6f, p.radius / 2f)); // larger red dot
                sr.setColor(1, 1, 1, 1);
            }
        }

        sr.end();
    }
    void renderGameOver() {
        batch.begin();

        String gameOverText = "GAME OVER";
        font.getData().setScale(3f);
        font.draw(batch, gameOverText, WORLD_W / 2f - 150, WORLD_H / 2f + 80);

        String winnerText = "PLAYER " + (winner + 1) + " WON!";
        font.getData().setScale(2.5f);
        font.draw(batch, winnerText, WORLD_W / 2f - 120, WORLD_H / 2f + 20);

        String restartText = "Press R to Restart";
        font.getData().setScale(1.5f);
        font.draw(batch, restartText, WORLD_W / 2f - 100, WORLD_H / 2f - 40);

        font.getData().setScale(1.2f);

        batch.end();

        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            resetGame();
            gameState = GameState.PLAYING;
        }
    }

    void handleInput(float dt) {
        Tank cur = tanks[currentPlayer];

        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            tanks[0].x = Math.max(0, tanks[0].x - 140f * dt);
            tanks[0].y = getGroundHeight(tanks[0].x) + 10;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            tanks[0].x = Math.min(WORLD_W, tanks[0].x + 140f * dt);
            tanks[0].y = getGroundHeight(tanks[0].x) + 10;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.J)) {
            tanks[1].x = Math.max(0, tanks[1].x - 140f * dt);
            tanks[1].y = getGroundHeight(tanks[1].x) + 10;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.L)) {
            tanks[1].x = Math.min(WORLD_W, tanks[1].x + 140f * dt);
            tanks[1].y = getGroundHeight(tanks[1].x) + 10;
        }
        if (projectiles.isEmpty() || allProjectilesInactive()) {
            if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) cur.angle += 60 * dt;
            if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) cur.angle -= 60 * dt;
            if (Gdx.input.isKeyPressed(Input.Keys.UP)) cur.power = Math.min(400, cur.power + 120 * dt);
            if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) cur.power = Math.max(20, cur.power - 120 * dt);

            if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) cur.selected = ProjectileType.CRANBERRY;
            if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) cur.selected = ProjectileType.WISHBONE;
            if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) cur.selected = ProjectileType.DRUMSTICK;

            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) fireCurrentWeapon(cur);
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) resetGame();
    }

    boolean allProjectilesInactive() {
        return projectiles.isEmpty();
    }

    void fireCurrentWeapon(Tank cur) {
        float rad = (float) Math.toRadians(cur.angle);
        Vector2 v = new Vector2((float) Math.cos(rad) * cur.power, (float) Math.sin(rad) * cur.power);
        Projectile p = new Projectile(new Vector2(cur.x, cur.y + 8), v, cur.selected, currentPlayer);

        if (p.type == ProjectileType.DRUMSTICK && drumstickRegion != null) {
            p.spriteRegion = drumstickRegion;
            p.spriteScale = 3f;
        } else if (p.type == ProjectileType.WISHBONE && wishboneRegion != null) {
            p.spriteRegion = wishboneRegion;
            p.spriteScale = 3f;
        } else {
            p.spriteRegion = null;
            p.spriteScale = 1f;
        }
        if (shootSound != null) {
            shootSound.play(0.5f); // volume 0.5
        }

        projectiles.add(p);
    }

    void updateProjectiles(float dt) {
        if (projectiles.isEmpty()) return;
        Iterator<Projectile> it = projectiles.iterator();
        ArrayList<Projectile> toAdd = new ArrayList<>();
        while (it.hasNext()) {
            Projectile proj = it.next();
            proj.time += dt;
            proj.vel.y += gravity * dt;
            proj.pos.x += proj.vel.x * dt;
            proj.pos.y += proj.vel.y * dt;

            if (proj.pos.x < -200 || proj.pos.x > WORLD_W + 200 || proj.pos.y < -200) {
                it.remove();
                continue;
            }

            float groundH = getGroundHeight(proj.pos.x);
            if (proj.pos.y <= groundH) {
                explode(proj.pos.x, proj.pos.y, proj.radius, proj.owner);
                it.remove();
                continue;
            }

            for (int i = 0; i < 2; i++) {
                if (i == proj.owner) continue;
                Tank t = tanks[i];
                float dx = t.x - proj.pos.x, dy = t.y - proj.pos.y;
                if (dx * dx + dy * dy < 20 * 20) {
                    t.health -= proj.damage;
                    if (t.health < 0) t.health = 0;
                    it.remove();
                    break;
                }

            }

            if (proj.type == ProjectileType.WISHBONE && !proj.split && proj.time > 0.25f) {
                proj.split = true;
                Vector2 v1 = proj.vel.cpy().rotate(18), v2 = proj.vel.cpy().rotate(-18);
                Projectile c1 = new Projectile(proj.pos.cpy(), v1, ProjectileType.WISHBONE, proj.owner);
                Projectile c2 = new Projectile(proj.pos.cpy(), v2, ProjectileType.WISHBONE, proj.owner);
                c1.split = true;
                c2.split = true;
                c1.radius = 12;
                c2.radius = 12;
                c1.damage = 12;
                c2.damage = 12;
                if (wishboneRegion != null) {
                    c1.spriteRegion = wishboneRegion;
                    c2.spriteRegion = wishboneRegion;
                    c1.spriteScale = 3f * 0.6f;
                    c2.spriteScale = 3f * 0.6f;
                }
                toAdd.add(c1);
                toAdd.add(c2);
            }
        }
        projectiles.addAll(toAdd);
        if (projectiles.isEmpty()) endTurn();
    }

    void explode(float x, float y, float radius, int owner) {
        for (int i = 0; i < 2; i++) {
            if (i == owner) continue;
            Tank t = tanks[i];
            float dx = t.x - x, dy = t.y - y;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < radius) {
                int damage = (int) ((1 - d / radius) * 100);
                t.health -= damage;
                if (t.health < 0) t.health = 0;
            }
        }
    }

    void endTurn() {
        currentPlayer = 1 - currentPlayer;
        for (Tank t : tanks) t.y = getGroundHeight(t.x) + 10;
    }

    void resetGame() {
        generateGround();
        tanks[0] = new Tank(100, getGroundHeight(100) + 10, true);
        tanks[1] = new Tank(500, getGroundHeight(500) + 10, false);
        tanks[0].health = 100;
        tanks[1].health = 100;
        currentPlayer = 0;
        projectiles.clear();
    }

    @Override
    public void dispose() {
        batch.dispose();
        sr.dispose();
        font.dispose();
        if (turkeySheet != null) turkeySheet.dispose();
        if (titleScreenTexture != null) titleScreenTexture.dispose();
        if (shootSound != null) shootSound.dispose();
        winner = -1;
    }

    static class Tank {
        float x, y;
        float angle = 45;
        float power = 180;
        float barrelLength = 18;
        int health = 100;
        ProjectileType selected = ProjectileType.CRANBERRY;
        boolean isLeft;

        Tank(float x, float y, boolean left) {
            this.x = x;
            this.y = y;
            this.isLeft = left;
            if (!left) angle = 135;
        }
    }

    enum ProjectileType { CRANBERRY, DRUMSTICK, WISHBONE }

    static class Projectile {
        Vector2 pos, vel;
        ProjectileType type;
        float time = 0f;
        boolean split = false;
        int owner;
        int damage;
        float radius;
        TextureRegion spriteRegion = null;
        float spriteScale = 1f;

        Projectile(Vector2 p, Vector2 v, ProjectileType t, int owner) {
            pos = p.cpy();
            vel = v.cpy();
            type = t;
            this.owner = owner;
            if (t == ProjectileType.CRANBERRY) {
                damage = 10;
                radius = 12;
            } else if (t == ProjectileType.DRUMSTICK) {
                damage = 25;
                radius = 70;
            } else {
                damage = 12;
                radius = 25;
            }
        }
    }
}
